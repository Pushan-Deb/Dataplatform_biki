import os

import setproctitle

from airflow import settings

bind = "0.0.0.0:8080"
workers = int(os.getenv("AIRFLOW__WEBSERVER__WORKERS", "1"))
worker_class = "sync"
timeout = int(os.getenv("AIRFLOW__WEBSERVER__WEB_SERVER_MASTER_TIMEOUT", "300"))
accesslog = "-"
errorlog = "-"
preload_app = False


def post_worker_init(_worker):
    old_title = setproctitle.getproctitle()
    setproctitle.setproctitle(settings.GUNICORN_WORKER_READY_PREFIX + old_title)
