import faulthandler

from airflow.www.app import create_app

print("serve_airflow: importing app factory", flush=True)
faulthandler.dump_traceback_later(30, repeat=False)
app = create_app()
print("serve_airflow: app created", flush=True)

if __name__ == "__main__":
    print("serve_airflow: starting Flask server", flush=True)
    app.run(host="0.0.0.0", port=8080, debug=False, use_reloader=False, threaded=True)
