import streamlit as st

# Main entry stays `app.py`, but UI is split into folders/files for team work.
from ui.config import setup_page
from ui.state import init_state
from ui.auth import qp_autologin
from ui.router import router

setup_page()
init_state()
qp_autologin()
router()
