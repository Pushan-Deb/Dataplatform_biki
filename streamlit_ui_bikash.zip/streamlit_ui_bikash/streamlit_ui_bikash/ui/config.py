import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(dotenv_path=Path(__file__).resolve().parent.parent / ".env")

# Keycloak
KEYCLOAK_SERVER   = os.getenv("KEYCLOAK_SERVER",   "http://10.155.38.139:8090")
REALM             = os.getenv("KEYCLOAK_REALM",    "ckuens-platform")
CLIENT_ID         = os.getenv("KEYCLOAK_CLIENT_ID","data-platform-ui")
CLIENT_SECRET     = os.getenv("KEYCLOAK_CLIENT_SECRET", "")
REDIRECT_URI      = os.getenv("KEYCLOAK_REDIRECT_URI",  "http://10.155.38.206:8501")

# Airflow
AIRFLOW_URL       = os.getenv("AIRFLOW_URL",  "http://10.155.38.139:8080")
AIRFLOW_API       = os.getenv("AIRFLOW_API",  "http://10.155.38.139:8080/api/v2")

# OpenMetadata
OPENMETADATA_URL  = os.getenv("OPENMETADATA_URL", "http://10.155.38.139:8585")
OPENMETADATA_API  = os.getenv("OPENMETADATA_API", "http://10.155.38.139:8585/api/v1")

# Marquez / OpenLineage
MARQUEZ_UI        = os.getenv("MARQUEZ_UI",  "http://10.155.38.139:3000")
MARQUEZ_API       = os.getenv("MARQUEZ_API", "http://10.155.38.139:5000")

# Vault
VAULT_URL         = os.getenv("VAULT_URL",   "http://10.155.38.155:8200")

# MinIO
MINIO_URL         = os.getenv("MINIO_URL",      "http://10.155.38.155:9001")
MINIO_ENDPOINT    = os.getenv("MINIO_ENDPOINT", "http://10.155.38.155:9000")
MINIO_ACCESS_KEY  = os.getenv("MINIO_ACCESS_KEY", "dataplatform")
MINIO_SECRET_KEY  = os.getenv("MINIO_SECRET_KEY", "Dataplatform@123")

# Airbyte
AIRBYTE_UI        = os.getenv("AIRBYTE_UI",  "http://10.155.38.206:8000")
AIRBYTE_API       = os.getenv("AIRBYTE_API", "http://10.155.38.206:8001")

# Spark
SPARK_MASTER      = os.getenv("SPARK_MASTER",     "spark://10.155.38.206:7077")
SPARK_MASTER_URL  = os.getenv("SPARK_MASTER_URL", "spark://10.155.38.206:7077")
SPARK_UI          = os.getenv("SPARK_UI",         "http://10.155.38.206:8080")
SPARK_CUSTOM_API  = os.getenv("SPARK_CUSTOM_API", "http://10.155.38.206:9003")
SPARK_REST_URL    = os.getenv("SPARK_REST_URL",   "http://10.155.38.206:9003")

# Kafka
KAFKA_BOOTSTRAP        = os.getenv("KAFKA_BOOTSTRAP",         "10.155.38.206:9092")
KAFKA_REST_PROXY       = os.getenv("KAFKA_REST_PROXY",        "http://10.155.38.206:8082")
KAFKA_SCHEMA_REGISTRY  = os.getenv("KAFKA_SCHEMA_REGISTRY_URL","http://10.155.38.206:8181")
KAFKA_CONTROL_CENTER   = os.getenv("KAFKA_CONTROL_CENTER",    "http://10.155.38.206:9021")

# Trino
TRINO_URL         = os.getenv("TRINO_URL",  "http://10.155.38.206:8090")

# Health API
HEALTH_API        = os.getenv("HEALTH_API", "http://10.155.38.139:8005/api/health")

# Grafana
GRAFANA_KAFKA     = os.getenv("GRAFANA_KAFKA", "http://10.155.38.139:3000")
GRAFANA_MINIO     = os.getenv("GRAFANA_MINIO", "http://10.155.38.139:3000")

# Shared credentials
PLATFORM_USERNAME = os.getenv("PLATFORM_USERNAME", "dataplatform")
PLATFORM_PASSWORD = os.getenv("PLATFORM_PASSWORD", "Dataplatform@123")

ROLE_TEAMS = {
    "Admin":         "Platform",
    "Data Engineer": "DataEng",
    "Data Analyst":  "Analytics",
    "ML Engineer":   "ML",
}