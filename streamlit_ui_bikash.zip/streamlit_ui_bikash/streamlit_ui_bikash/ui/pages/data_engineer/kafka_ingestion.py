import streamlit as st
import pandas as pd
import requests
import os
from ui.services.jobs import add_job, ensure_dummy_jobs
from ui.services.lineage import add_lineage_edge
from ui.services.utils import with_run_ts
from ui.state import enforce
from ui.config import KAFKA_BOOTSTRAP, SPARK_CUSTOM_API

# ── All ZeroTier IPs — reachable from any laptop on 10.155.38.* network ────
# spark-api container  → 10.155.38.206:9003  (POST /api/v1/jobs/submit)
# Kafka REST Proxy     → 10.155.38.206:8082
# MinIO                → 10.155.38.155:9000
# Spark Master UI      → 10.155.38.206:8080
# Keycloak             → 10.155.38.139:8090
SPARK_API        = "http://10.155.38.206:9003"
KAFKA_REST_PROXY = os.getenv("KAFKA_REST_PROXY", "http://10.155.38.206:8082")
MINIO_ENDPOINT   = os.getenv("MINIO_ENDPOINT",   "http://10.155.38.155:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "dataplatform")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "Dataplatform@123")


def success_box(markdown_text: str):
    st.markdown(
        f"<div class='successbox'>{markdown_text}</div>",
        unsafe_allow_html=True,
    )


# ── Kafka ───────────────────────────────────────────────────────────────────

def _get_cluster_id() -> str | None:
    try:
        r = requests.get(
            f"{KAFKA_REST_PROXY}/v3/clusters",
            headers={"Accept": "application/json"},
            timeout=8,
        )
        r.raise_for_status()
        data = r.json().get("data", [])
        return data[0]["cluster_id"] if data else None
    except Exception:
        return None


def kafka_create_topic(topic: str, partitions: int = 3,
                       replication: int = 1) -> dict:
    try:
        cluster_id = _get_cluster_id()
        if not cluster_id:
            return {"status": "ERROR",
                    "message": f"Cannot reach Kafka REST Proxy at {KAFKA_REST_PROXY}"}

        r = requests.get(
            f"{KAFKA_REST_PROXY}/v3/clusters/{cluster_id}/topics/{topic}",
            headers={"Accept": "application/json"},
            timeout=8,
        )
        if r.status_code == 200:
            return {"status": "EXISTS",
                    "message": f"Topic '{topic}' already exists"}

        r2 = requests.post(
            f"{KAFKA_REST_PROXY}/v3/clusters/{cluster_id}/topics",
            headers={"Content-Type": "application/json",
                     "Accept":       "application/json"},
            json={
                "topic_name":         topic,
                "partitions_count":   partitions,
                "replication_factor": replication,
                "configs": [
                    {"name": "retention.ms",   "value": "604800000"},
                    {"name": "cleanup.policy", "value": "delete"},
                ],
            },
            timeout=10,
        )
        if r2.status_code in (200, 201):
            return {"status": "CREATED",
                    "message": f"Topic '{topic}' created"}
        if r2.status_code == 409:
            return {"status": "EXISTS",
                    "message": f"Topic '{topic}' already exists"}
        return {"status": "ERROR",
                "message": f"HTTP {r2.status_code}: {r2.text[:200]}"}

    except requests.exceptions.ConnectionError:
        return {"status": "ERROR",
                "message": f"Cannot connect to Kafka REST Proxy at {KAFKA_REST_PROXY}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}


# ── Spark ───────────────────────────────────────────────────────────────────

def spark_submit_streaming_job(topic: str, dest_path: str,
                                checkpoint_path: str) -> dict:
    """
    POST http://10.155.38.206:9003/api/v1/jobs/submit
    spark-api container resolves spark-master internally via Docker network.
    The UI calls spark-api via ZeroTier IP — works from any laptop.
    """
    payload = {
        "job_type": "kafka_stream",         # → /opt/spark-jobs/kafka_stream.py
        "app_name": f"kafka-stream-{topic}",
        "app_args": [
            "--topic",      topic,
            "--broker",     KAFKA_BOOTSTRAP,
            "--dest",       dest_path,
            "--checkpoint", checkpoint_path,
            "--minio",      MINIO_ENDPOINT,
        ],
        "spark_properties": {
            "spark.sql.extensions":
                "io.delta.sql.DeltaSparkSessionExtension",
            "spark.sql.catalog.spark_catalog":
                "org.apache.spark.sql.delta.catalog.DeltaCatalog",
            "spark.hadoop.fs.s3a.impl":
                "org.apache.hadoop.fs.s3a.S3AFileSystem",
            "spark.hadoop.fs.s3a.endpoint":          MINIO_ENDPOINT,
            "spark.hadoop.fs.s3a.access.key":        MINIO_ACCESS_KEY,
            "spark.hadoop.fs.s3a.secret.key":        MINIO_SECRET_KEY,
            "spark.hadoop.fs.s3a.path.style.access": "true",
            "spark.hadoop.fs.s3a.connection.ssl.enabled": "false",
            "spark.hadoop.fs.s3a.fast.upload":       "true",
            "spark.hadoop.fs.s3a.aws.credentials.provider":
                "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider",
            "spark.executor.memory": "512m",
            "spark.executor.cores":  "2",
            "spark.cores.max":       "4",
            "spark.driver.memory":   "1g",
        },
        "env_vars": {
            "KAFKA_BOOTSTRAP":  KAFKA_BOOTSTRAP,
            "KAFKA_TOPIC":      topic,
            "DEST_PATH":        dest_path,
            "CHECKPOINT_PATH":  checkpoint_path,
            "MINIO_ENDPOINT":   MINIO_ENDPOINT,
            "MINIO_ACCESS_KEY": MINIO_ACCESS_KEY,
            "MINIO_SECRET_KEY": MINIO_SECRET_KEY,
        },
    }

    try:
        r = requests.post(
            f"{SPARK_API}/api/v1/jobs/submit",
            headers={"Content-Type": "application/json"},
            json=payload,
            timeout=30,
        )
        if r.status_code == 200:
            data = r.json()
            if data.get("success"):
                return {
                    "status":       "SUBMITTED",
                    "submissionId": data["submissionId"],
                    "driverState":  data.get("driverState", "SUBMITTED"),
                    "message":      data.get("message", ""),
                }
            return {"status": "ERROR",
                    "message": data.get("message", str(data))}
        return {"status": "ERROR",
                "message": f"HTTP {r.status_code}: {r.text[:300]}"}

    except requests.exceptions.ConnectionError:
        return {"status": "ERROR",
                "message": f"Cannot connect to Spark API at {SPARK_API}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}


def spark_get_job_status(submission_id: str) -> str:
    try:
        r = requests.get(
            f"{SPARK_API}/api/v1/jobs/{submission_id}", timeout=8)
        if r.status_code == 200:
            return r.json().get("driverState", "UNKNOWN")
    except Exception:
        pass
    return "UNKNOWN"


# ── PAGE ────────────────────────────────────────────────────────────────────

def page_kafka_ingestion():
    st.title("Kafka Streaming Ingestion")
    st.caption(
        f"Kafka bootstrap: {KAFKA_BOOTSTRAP} | Spark Custom API: {SPARK_API}"
    )
    ensure_dummy_jobs()
    enforce("submit_ingestion")

    hierarchy = st.session_state.org_hierarchy

    topic        = st.text_input("Kafka topic", value="crm.contacts",
                                 key="kafka_topic")
    create_topic = st.checkbox("Create topic if not exists", value=True,
                               key="kafka_create_topic")
    filters      = st.text_input("Optional filters",
                                 value="event_type = 'UPSERT'",
                                 key="kafka_filters")

    l1      = st.selectbox("Level 1", list(hierarchy.keys()), key="kafka_l1")
    l2      = st.selectbox("Level 2",
                           list(hierarchy.get(l1, {}).keys()), key="kafka_l2")
    level3s = hierarchy.get(l1, {}).get(l2, [])
    l3      = st.selectbox("Level 3", level3s if level3s else [""],
                           key="kafka_l3")
    dest_dataset = st.text_input("Destination dataset name",
                                 value="contacts_stream",
                                 key="kafka_dest_dataset")

    base_prefix = f"s3a://delta-lake/{l1.lower()}/{l2}"
    if str(l3).strip():
        base_prefix += f"/{l3}"
    dest_base       = f"{base_prefix}/{dest_dataset}/"
    checkpoint_path = f"{base_prefix}/{dest_dataset}/_checkpoint/"

    st.dataframe(pd.DataFrame([{
        "Topic":                 topic,
        "Create topic":          "Yes" if create_topic else "No",
        "Filters":               filters,
        "Output (base)":         dest_base,
        "Suggested unique path": with_run_ts(dest_base),
    }]), use_container_width=True, hide_index=True)

    if st.button("Start streaming job", type="primary", key="kafka_submit"):

        # Step 1 — Kafka topic
        if create_topic:
            result = kafka_create_topic(topic)
            if result["status"] == "EXISTS":
                st.warning(f"⚠️ Topic already exists — reusing `{topic}`")
            elif result["status"] == "CREATED":
                st.success(f"✅ Topic `{topic}` created successfully")
            else:
                st.error(f"❌ Kafka error: {result['message']}")
                st.stop()
        else:
            st.info("ℹ️ Skipping topic creation")

        # Step 2 — Spark streaming job
        with st.spinner("Submitting Spark streaming job..."):
            spark_result = spark_submit_streaming_job(
                topic, dest_base, checkpoint_path)

        if spark_result["status"] == "SUBMITTED":
            sub_id       = spark_result["submissionId"]
            driver_state = spark_result.get("driverState", "SUBMITTED")

            st.success(f"✅ Spark job submitted — ID: `{sub_id}`")
            st.info(f"🔄 Driver state: `{driver_state}`")

            job_id, link, result_loc = add_job(
                "Kafka Stream",
                "Kafka → Spark Structured Streaming",
                dest_base,
                status="RUNNING",
                visibility="Team",
                source=f"KafkaTopic:{topic}",
                destination=dest_base,
            )
            add_lineage_edge("Kafka Topic", topic,  "Job",
                             job_id,    "feeds")
            add_lineage_edge("Job",         job_id, "Dataset",
                             dest_base, "writes_to")

            success_box(
                f"✅ Streaming started successfully.<br>"
                f"Spark ID: <b>{sub_id}</b> | "
                f"Driver: <b>{driver_state}</b><br>"
                f"Output: <code>{dest_base}</code><br>"
                f"<a href='{link}'>Open Job Details</a>"
                f" &nbsp;|&nbsp; "
                f"<a href='http://10.155.38.206:8080' target='_blank'>"
                f"Spark Master UI ↗</a>"
            )
        else:
            st.error(f"❌ Spark error: {spark_result['message']}")
            st.markdown(
                f"**Debug links:**\n"
                f"- Spark API: [{SPARK_API}/health]"
                f"({SPARK_API}/health)\n"
                f"- Spark Master UI: "
                f"[http://10.155.38.206:8080]"
                f"(http://10.155.38.206:8080)"
            )